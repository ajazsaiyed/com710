

document.getElementById("formid").onsubmit = function(e){
	e.preventDefault();
	
	let name = document.getElementById("name").value;
	let age = document.getElementById("age").value;

	if(age > 0 && age < 120)
	{
		document.getElementById("ex").innerHTML = "hello,My name is" + name + " I am " + age + "years old";
	}
	else
	{
		document.getElementById("ex").innerHTML ="Error";
	}

	document.getElementById("ex").style.backgroundColor="grey";
	document.getElementById("ex").style.color="black";
};