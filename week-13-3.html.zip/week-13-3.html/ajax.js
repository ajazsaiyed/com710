document.getElementById("ajax").onclick = function () {
    var xhttp = new XMLHttpRequest();
	
    xhttp.addEventListener("ajax", e => {
		alert("its worked")
        document.getElementById("ajax").innerHTML = e.target.responseText;
    });
	xhttp.open("GET", "text.html", true);
    xhttp.send();
};